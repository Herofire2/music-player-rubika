print('impor libs...')
import os
import asyncio
import random
import bs4
import requests
import googlesearch
from rubpy import Client, filters
from radiojavanapi import Client as RJClient
from sqlalchemy import create_engine, Column, String, Integer
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from pydub import AudioSegment
import httpx
import subprocess
import json
import tools
print('libs imported.')

help_text = """
   💬 **لیست دستورات ربات نیترو(لوپی میوزیک):**
   `$پخش` ریپلای روی آهنگ/ویس - [یا اسم اهنگ/ویس از لیست اهنگ ها].
   `$بعدی` - پخش اهنگ بعدی از روی لیست.
   `$قبلی` - پخش اهنگ قبلی از روی لیست.
   `$مجدد` [اسم اهنگ از روی لیست.] - پخش اهنگ از داخل لیست.
   `$توقف` - توقف پخش اهنگ.
   `$دانلود` [لینک مستقیم اهنگ یا اسم اهنگ] - دانلود اهنگ بدون پخش.
   $تغییر حالت - تغییر حالت پخش (پشت سر هم, شانسی, تکرار).
   $جستجوی گوگل [متن] - جستجوی اهنگ از گوگل.
   $لیست آهنگ ها - نمایش لیست آهنگ ها.
   $حذف آهنگ [اسم اهنگ در لیست] - حذف اهنگ مورد نظر.
   $وضعیت - نمایش وضعیت فعلی پخش.
   $راهنما - نمایش راهنمای ربات.

ساخته شده توسط l8py
"""

# ترجمه متن‌های دیگر
start_message = "🎶 ربات پخش موزیک فعال شد. برای راهنما دستور $راهنما را ارسال کنید."
no_song_playing = "⛔ هیچ آهنگی در حال پخش نیست."
now_playing = "🎧 اکنون در حال پخش"
added_to_queue = "➕ آهنگ '{}' به صف اضافه شد."
queue_is_empty = "⚠️ صف پخش خالی است."
playing_next = "⏭️ آهنگ بعدی در حال پخش"
playing_previos = "اهنگ قبلی پخش میشود⏮️"
stopped_playing = "🛑 پخش متوقف شد."
cleared_queue = "🗑️ صف پخش پاک شد."
searching_for_song = "🔍 در حال جستجوی '{}'."
Music_found_text ="🎶آهنگ {0} از {1} پیدا شد."
no_results_found = "❌ نتیجه‌ای یافت نشد."
invalid_song_index_text = "شماره اهنگ نا معتبر 🔴"
please_reply_text = "لطفاً روی اهنگ یا ویس ریپلای کنید🎚️"
# ترجمه دستورات و عملیات‌ها به فارسی

# Database setup
engine = create_engine('sqlite:///songs.db')
Base = declarative_base()

class Song(Base):
    __tablename__ = 'songs'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    artist = Column(String)
    url = Column(String)
    filepath = Column(String)

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
session = Session()

# Rubika client
bot = Client(name='botmusic',timeout=2000,display_welcome=False)
print('account loged in successful.')

# Radio Javan client
rj_client = RJClient()

# Active playback tasks
active_tasks = {}
active_prtasks = {}
current_song_index = {}
play_mode = {}

# 



async def download_file(download_url: str, file_path: str):
    url = "http://localhost:8001/download/"
    payload = {
        "url": download_url,
        "file_path": file_path
    }
    
    async with httpx.AsyncClient() as client:
        response = await client.post(url, params=payload)
        if response.status_code == 200:
            print(f"Success: {response.json()}")
        else:
            print(f"Failed: {response.status_code}, {response.text}")
            







async def download_file_rubpy(file_inline, save_as: str):
    link = await tools.getDLlink(file_inline)
    await download_file(download_url=link,file_path=save_as)



class Music:
    def __init__(self) -> None:
        self.query = None
        self.urls = None

    def Search(self):
        try:
            searched = googlesearch.search(f"دانلود اهنگ {self.query}", num_results=2)
            for i in searched:
                return [i]
        except Exception as e:
            print(f"Error searching: {e}")
            return []

    def Find(self):
        urls = []
        try:
            html = requests.get(self.Search()[0])
            bs = bs4.BeautifulSoup(html.content, "html.parser")
            result = bs.find_all("a")
            for url in result:
                object = str(url.get("href"))
                if object.endswith(".mp3"):
                    urls.append(object)
            self.urls = urls
        except Exception as e:
            print(f"Error finding links: {e}")
        
        return self.urls

@bot.on_message_updates(filters.text)
async def handle_message(update):
    print('new message: ' + update.text)
    query = update.text
    chat_id = update.object_guid

    if chat_id not in current_song_index:
        current_song_index[chat_id] = 0
        play_mode[chat_id] = "queue"  # Default play mode is queue

    if True:
        if query.startswith("$مجدد"):
            song_name = query[8:].strip()
            song = session.query(Song).filter_by(name=song_name).first()
            print(song)
            if song:
                await play_song(chat_id, song.filepath)
            else:
                await update.reply(no_results_found)
        
        elif query == "$بعدی":
            active_prtasks[chat_id].cancel()
            await play_next_song(chat_id)
            await update.reply(playing_next)
        elif query == "$قبلی":
            active_prtasks[chat_id].cancel()
            await play_previous_song(chat_id)
            await update.reply(playing_previos)
        elif query.startswith("$پخش شماره"):
            try:
                song_number = int(query.replace('$پخش شماره','')) - 1
                await play_song_by_index(chat_id, song_number)
            except ValueError:
                await update.reply(invalid_song_index_text)
        elif query == '$پخش':
            if update.reply_message_id:
                reply_message = await update.get_reply_message()
                if reply_message.file_inline.type == 'Voice':
                    existing_song = session.query(Song).filter_by(name=reply_message.file_inline.file_name).first()
                    print(existing_song)
                    if existing_song:
                        await update.reply(Music_found_text.format({existing_song.name},{existing_song.artist}))
                        await play_song(chat_id, existing_song.filepath)
                    else:
                        await download_file_rubpy(reply_message.file_inline,f'song_cache/{reply_message.file_inline.file_name}')
                        await asyncio.sleep(12)
                        await update.reply(f"فایل ویس دریافت شد: {reply_message.file_inline.file_name}")
                        new_song = Song(name=reply_message.file_inline.file_name, artist='Rubika Voice', url='rubika', filepath=f'song_cache/{reply_message.file_inline.file_name}')
                        data = session.add(new_song)
                        print(data)
                        session.commit()
                        await play_song(chat_id, f'song_cache/{reply_message.file_inline.file_name}')
                
                elif reply_message.file_inline.type == 'Music':
                    existing_song = session.query(Song).filter_by(name=reply_message.file_inline.file_name, artist=reply_message.file_inline.music_performer).first()
                    print(existing_song)
                    if existing_song:
                        await update.reply(Music_found_text.format({existing_song.name},{existing_song.artist}))
                        await play_song(chat_id, existing_song.filepath)
                    else:
                        await download_file_rubpy(reply_message.file_inline,f'song_cache/{reply_message.file_inline.file_name}')
                        await asyncio.sleep(12)
                        await download_and_save_file(reply_message.file_inline.file_name, reply_message.file_inline.mime, chat_id, False, reply_message.file_inline.music_performer, update)
                
                
            
            else:
                await update.reply(please_reply_text)
        
        elif query == '$دانلود':
            if update.reply_message_id:
                reply_message = await update.get_reply_message()
                if reply_message.file_inline.type == 'Voice':
                    existing_song = session.query(Song).filter_by(name=reply_message.file_inline.file_name).first()
                    if existing_song:
                        await update.reply(Music_found_text.format({existing_song.name},{existing_song.artist}))
                    
                    else:
                        await download_file_rubpy(reply_message.file_inline,f'song_cache/{reply_message.file_inline.file_name}')
                        await asyncio.sleep(12)
                        await update.reply(added_to_queue.format({reply_message.file_inline.file_name}))
                        new_song = Song(name=reply_message.file_inline.file_name, artist='Rubika Voice', url='rubika', filepath=f'song_cache/{reply_message.file_inline.file_name}')
                        session.add(new_song)
                        session.commit()
                
                elif reply_message.file_inline.type == 'Music':
                    existing_song = session.query(Song).filter_by(name=reply_message.file_inline.file_name, artist=reply_message.file_inline.music_performer).first()
                    print(existing_song)
                    if existing_song:
                        await update.reply(Music_found_text.format({existing_song.name},{existing_song.artist}))
                        await update.reply(added_to_queue.format({reply_message.file_inline.file_name}))
                    else:
                        await download_file_rubpy(reply_message.file_inline,f'song_cache/{reply_message.file_inline.file_name}')
                        await asyncio.sleep(12)
                        await download_and_save_file(reply_message.file_inline.file_name, reply_message.file_inline.mime, chat_id, True, reply_message.file_inline.music_performer, update)
                
                
            
            else:
                await update.reply(please_reply_text)
        
        elif query.startswith("$پخش "):
            query = query.replace('$پخش ', '')
            await search_and_play(update, query, chat_id)
        elif query == '$توقف':
            
            current_song_index[chat_id] = 0
            active_tasks[chat_id].cancel()
            active_prtasks[chat_id].cancel()
            await bot.voice_chat_player(chat_id,'song_cache/stop.ogg')
            await update.reply(stopped_playing)
        elif query == "$تغییر حالت":
            await change_play_mode(chat_id, update)
        elif query.startswith("$دانلود "):
            query = query[10:].strip()
            if query.startswith("http"):
                await download_direct_link(update, query, chat_id)
            else:
                await search_and_play(update, query, chat_id, download_only=True)
        elif query.startswith("$جستجوی گوگل"):
            query = query.replace('$جستجوی گوگل ', '')
            await search_and_download_google(update, query, chat_id)
        elif query == "$لیست آهنگ ها":
            await list_songs(update, chat_id)
        elif query.startswith("$حذف آهنگ "):
            song_name = query.replace('$حذف آهنگ ', '')
            await delete_song(update, song_name)
        elif query == "$وضعیت":
            await show_status(update, chat_id)
        elif query == "$راهنما":
            await show_help(update)
    

async def show_status(update, chat_id):
    try:
        songs = session.query(Song).all()
        if not songs:
            await update.reply(queue_is_empty)
            return

        current_index = current_song_index[chat_id]
        current_song = songs[current_index]

        next_song = songs[(current_index + 1) % len(songs)]
        previous_song = songs[(current_index - 1) % len(songs)]

        mode_texts = {
            "repeat": "تکرار",
            "shuffle": "شانسی",
            "queue": "پشت سر هم"
        }

        status_message = (
            f"🎵 **وضعیت پخش:**\n"
            f"اهنگ فعلی: {current_song.name} by {current_song.artist}\n"
            f"حالت پخش: {mode_texts[play_mode[chat_id]]}\n"
            f"اهنگ قبلی: {previous_song.name} by {previous_song.artist}\n"
            f"اهنگ بعدی: {next_song.name} by {next_song.artist}"
        )

        await update.reply(status_message)
    except Exception as e:
        print(f"Error displaying status: {e}")

async def show_help(update):
    await update.reply(help_text)


# import asyncio
# from pydub import AudioSegment

class numToPersian:


    @staticmethod
    def format_time(num):
        if num >= 3600:
            hours = num // 3600
            minutes = (num % 3600) // 60
            seconds = num % 60
            if minutes == 0 and seconds == 0:
                return f"{hours}h"
            elif seconds == 0:
                return f"{hours}h {minutes}m"
            elif minutes == 0:
                return f"{hours}س {seconds}ث"
            else:
                return f"{hours}h {minutes}m {seconds}s"
        elif num >= 60:
            minutes = num // 60
            seconds = num % 60
            if seconds == 0:
                return f"{minutes}د"
            else:
                return f"{minutes}د {seconds}ث"
        else:
            return f"{num}ث"



async def play_song(chat_id, file_path):
    # لغو تسک قبلی اگر وجود داشته باشد
    if chat_id in active_tasks or chat_id in active_prtasks:
        active_tasks[chat_id].cancel()
        active_prtasks[chat_id].cancel()

    # تابع برای بدست آوردن مدت زمان فایل صوتی
    def get_duration(file_path):
        audio = AudioSegment.from_file(file_path)
        return len(audio) / 1000  # مدت زمان به ثانیه

    duration = get_duration(file_path)
    print(f"Duration of {file_path}: {duration} seconds")
    formated = numToPersian.format_time(duration)
    # تابع برای پخش صوت با استفاده از bot.voice_chat_player
    async def play_audio(file_path):
        await bot.voice_chat_player(chat_id, file_path)
        print(f"Finished playing {file_path}")

    # تابع برای مدیریت زمان و به‌روزرسانی پیام
    async def update_progress(duration):
        data = await bot.send_message(chat_id, f'اهنگ: {file_path}\n\nزمان: 0/{formated}')
        second = 0
        while second <= duration - 5:
            await asyncio.sleep(1)
            second += 1
            second_format = numToPersian.format_time(second)
            await bot.edit_message(chat_id, data.message_id, f'اهنگ: {file_path}\n\nزمان: {second_format}/{formated}')
        await post_play_actions(chat_id)

    # ایجاد و شروع تسک‌ها
    play_task = asyncio.create_task(play_audio(file_path))
    update_task = asyncio.create_task(update_progress(duration))

    # ذخیره تسک‌ها در دیکشنری فعال
    active_tasks[chat_id] = play_task
    active_prtasks[chat_id] = update_task

    # منتظر اتمام هر دو تسک
    await asyncio.gather(play_task, update_task)

    print("Music finished successfully.")
   


async def play_next_song(chat_id):
    try:
        songs = session.query(Song).all()

        if play_mode[chat_id] == "shuffle":
            current_song_index[chat_id] = random.randint(0, len(songs) - 1)
        else:
            current_song_index[chat_id] = (current_song_index[chat_id] + 1) % len(songs)

        await play_song(chat_id, songs[current_song_index[chat_id]].filepath)
    except Exception as e:
        print(f"Error playing next song: {e}")






async def play_previous_song(chat_id):
    songs = session.query(Song).all()
    if not songs:
        await bot.send_message(chat_id, queue_is_empty)
        return

    current_song_index[chat_id] = (current_song_index[chat_id] - 1) % len(songs)
    await play_song(chat_id, songs[current_song_index[chat_id]].filepath)

async def play_song_by_index(chat_id, song_index):
    songs = session.query(Song).all()
    if not songs:
        await bot.send_message(chat_id, queue_is_empty)
        return

    if song_index < 0 or song_index >= len(songs):
        await bot.send_message(chat_id, invalid_song_index_text)
        return

    current_song_index[chat_id] = song_index
    await play_song(chat_id, songs[song_index].filepath)

async def change_play_mode(chat_id, update):
    modes = ["queue", "shuffle", "repeat"]
    current_mode = play_mode[chat_id]
    new_mode = modes[(modes.index(current_mode) + 1) % len(modes)]
    play_mode[chat_id] = new_mode
    mode_texts = {
            "repeat": "تکرار🔂",
            "shuffle": "شانسی🎲",
            "queue": "پشت سر هم🔁"
        }
    await update.reply(f"حالت پخش تغییر کرد: {mode_texts[new_mode]}.")

async def search_and_play(update, query, chat_id, download_only=False):
    try:
        await update.reply(f"در حال جستجو برای: {query}")
        song = rj_client.search(query)
        if song:
            existing_song = session.query(Song).filter_by(name=song.songs[0].title, artist=song.songs[0].artist).first()
            print(existing_song)
            if existing_song:
                await update.reply(f"آهنگ قبلا ذخیره شده: {existing_song.name} توسط {existing_song.artist}")
                if not download_only:
                    await play_song(chat_id, existing_song.filepath)
            else:
                await update.reply(f"آهنگ پیدا شد: {song.songs[0].title} توسط {song.songs[0].artist}")
                await download_and_save(song, chat_id, download_only,update)
        else:
            await update.reply("آهنگی یافت نشد.")
    except Exception as e:
        await update.reply(f"خطا در جستجو و پخش آهنگ: {e}")
async def delete_song(update, song_name):
    song = session.query(Song).filter_by(name=song_name).first()
    if song:
        session.delete(song)
        session.commit()
        await update.reply(f"آهنگ حذف شد: {song_name}")
    else:
        await update.reply(no_results_found)

async def list_songs(update, chat_id):
    songs = session.query(Song).all()
    if not songs:
        await update.reply(queue_is_empty)
        return

    song_list = "\n".join([f"{index + 1}. {song.name} by {song.artist}" for index, song in enumerate(songs)])
    await update.reply(f"🎵 **لیست آهنگ ها:**\n{song_list}")

async def download_and_save_file(file_name, mime_type, chat_id, play_immediately, performer, update):
    file_path = f"song_cache/{file_name}"
        
    
    output_file_path = file_path
    
    
    
    new_song = Song(name=file_name, artist=performer, url='rubika', filepath=output_file_path)
    data = session.add(new_song)
    print(data)
    session.commit()
    await update.reply(f"آهنگ دریافت شد: {file_name} از {performer}")
    if not bool(play_immediately):
        await play_song(chat_id, output_file_path)



async def search_and_download_google(update, query, chat_id):
    existing_song = session.query(Song).filter_by(name=query).first()
    
    print(existing_song)
    if existing_song:
      await update.reply('آهنگ قبلا دانلود شده بود')
      return await play_song(chat_id, existing_song.filepath)
    music = Music()
    music.query = query
    try:
        links = music.Find()
        print(links)
        if not links:
            await update.reply(no_results_found)
            return
        
        await update.reply(f"لینک یافت شد: {links[0]}")
        file_name = links[0].split('/')[-1]
        file_path = f"song_cache/{file_name}"
        
        await download_file(links[0], file_path)
        await asyncio.sleep(11)
        output_file_path = file_path
        # ذخیره اطلاعات آهنگ در دیتابیس
        new_song = Song(name=query, artist="Google", url=links[0], filepath=output_file_path)
        data = session.add(new_song)
        print(data)
        session.commit()

        await play_song(chat_id, output_file_path)
    except Exception as e:
        await update.reply(f"خطا در جستجو و دانلود از گوگل: {e}")


async def post_play_actions(chat_id):
    try:
        mode = play_mode[chat_id]
        
        if mode == "repeat":
            await play_song(chat_id, session.query(Song).all()[current_song_index[chat_id]].filepath)
        elif mode == "queue" or mode == "shuffle":
            await play_next_song(chat_id)
    except Exception as e:
        print(f"Error in post-play actions: {e}")





async def download_direct_link(update, link, chat_id):
    try:
        file_name = link.split('/')[-1]
        file_path = f"song_cache/{file_name}"
        await download_file(link, file_path)
        await asyncio.sleep(11)
        
        output_file_path = file_path
        # ذخیره اطلاعات آهنگ در دیتابیس
        new_song = Song(name=file_name, artist="دانلود مستقیم", url=link, filepath=output_file_path)
        data = session.add(new_song)
        print(data)
        session.commit()

        await play_song(chat_id, file_path)
    except Exception as e:
        await update.reply(f"خطا در دانلود آهنگ از لینک مستقیم: {e}")
        
async def download_and_save(song, chat_id, download_only,update):
    try:
        audio_id = song.songs[0].id
        audio_url = rj_client.get_song_by_id(audio_id).hq_link
        file_name = f"{song.songs[0].title}_{song.songs[0].artist}.m4a"
        file_path = f"song_cache/{file_name}"
        await download_file(audio_url, file_path)
        await asyncio.sleep(11)

        # تبدیل فایل m4a به ogg
        output_file_path = file_path

        if os.path.exists(output_file_path):
            new_song = Song(name=song.songs[0].title, artist=song.songs[0].artist, url=audio_url, filepath=output_file_path)
            session.add(new_song)
            session.commit()
            if not download_only:
                await play_song(chat_id, output_file_path)
        else:
            await update.reply("خطا در تبدیل فرمت فایل.")

        # حذف فایل‌های موقت

    except Exception as e:
        await update.reply(f"خطا در دانلود و ذخیره آهنگ: {e}")
        






bot.run()