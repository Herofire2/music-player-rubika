import subprocess
import signal
import sys
import threading
import os
import asyncio
# برای ذخیره پروسه ها
processes = []
def prRed(skk): print("\033[91m {}\033[00m" .format(skk))
 
 
def prGreen(skk): print("\033[92m {}\033[00m" .format(skk))
 
 
def prYellow(skk): print("\033[93m {}\033[00m" .format(skk))
 
 
def prLightPurple(skk): print("\033[94m {}\033[00m" .format(skk))
 
 
def prPurple(skk): print("\033[95m {}\033[00m" .format(skk))
 
 
def prCyan(skk): print("\033[96m {}\033[00m" .format(skk))
 
 
def prLightGray(skk): print("\033[97m {}\033[00m" .format(skk))
 
 
def prBlack(skk): print("\033[98m {}\033[00m" .format(skk))
 
just_run = False
do_notdo = input('just run? (y/n):')
if do_notdo == 'n':
  just_run = False
else:
  just_run = True
# تابع برای نصب پکیج‌ها
def install_packages():
    os.system('pip install -U radiojavanapi')
    packages = [
         'uvicorn', 'pydub', 'httpx', 'sqlalchemy', 
        'requests', 'bs4', 'fastapi','googlesearch-python', 'rubpy==7.0.6','aiortc', 'radiojavanapi', 'aiofiles'
    ]  # لیست پکیج‌های مورد نیاز
    for pk in packages:
      print()
      print()
      print()
      print(pk)
      print()
      print()
      os.system(f'pip install -U {pk}')
      os.system('clear')

# تابع برای خواندن لاگ‌های فرآیند و نمایش با پیشوند مناسب
def stream_output(process, prefix):
    for line in iter(process.stdout.readline, b''):
        print(f"[\033[92m{prefix}\033[00m] {line.decode('utf-8').strip()}")

# مدیریت سیگنال های Ctrl+C
def signal_handler(sig, frame):
    print('Stopping all processes...')
    for process in processes:
        process.terminate()  # خاتمه دادن به پروسه
    sys.exit(0)

# ثبت سیگنال Ctrl+C
signal.signal(signal.SIGINT, signal_handler)

# اجرای فرآیند‌ها
def run_processes():
    try:
        main_process = subprocess.Popen(['python3', 'main.py'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        processes.append(main_process)
        threading.Thread(target=stream_output, args=(main_process, 'main')).start()
        # اجرای سرور FastAPI با uvicorn
        server_process = subprocess.Popen(
            ['uvicorn', 'server:app', '--host', 'localhost', '--port', '8001'],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT
        )
        processes.append(server_process)
        threading.Thread(target=stream_output, args=(server_process, 'server')).start()

        # اجرای برنامه اصلی و گرفتن لاگ‌ها
        

        # صبر برای اتمام پروسه ها
        main_process.wait()
        server_process.wait()

    except Exception as e:
        print(f"An error occurred: {e}")
        signal_handler(None, None)


async def user_data():
  from rubpy import Client
  print('login to account...\n')
  async with Client('botmusic',display_welcome=False) as bot:
    data = await bot.get_me()
    prYellow('bot running in usr: ' + data.first_name)

if __name__ == "__main__":
    # نصب پکیج‌ها
    if not just_run:
      install_packages()
    asyncio.run(user_data())
      # TODO: write code...
    # اجرای فرآیندها
    run_processes()
