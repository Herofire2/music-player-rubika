import re





async def clean_gap(bot, chat_guid, num,start):
  print('1')
  d = int(num)
  r = await bot.get_messages_interval(chat_guid, start)
  print('2')
  cou = 0
  try:
    for de in r['messages']:
      cou += 1
      print(cou)
      await bot.delete_messages(chat_guid,de['message_id'])
      print(de['text'])
      if cou == d:
        print('breaked')
        break
  except Exception as exc:
    print(exc)
  
  await bot.send_message(chat_guid,f'• {cou} message deleted •')





def between(first: str = "", second: str = "", input_string="") -> str:
    
    m = re.search(f"{first}(.+?){second}", input_string)
    if m:
        return m.group(1)

    else:
        return ""



async def getDLlink(fileInline:dict) -> str:
  return f'https://messenger{fileInline["dc_id"]}.iranlms.ir/InternFile.ashx?id={fileInline["file_id"]}&ach={fileInline["access_hash_rec"]}'





# Define regular expressions for patterns
RUBIKA_LINK_PATTERN = re.compile(r'\brubika\.ir\b')
GROUP_LINK_PATTERN = re.compile(r'https://rubika\.ir/joing/[A-Z0-9]+')
CHANNEL_LINK_PATTERN = re.compile(r'https://rubika\.ir/joinc/[A-Z0-9]+')
USERNAME_PATTERN = re.compile(r'@([a-zA-Z0-9_]{3,32})')

# Functions to check patterns
def is_rubika_link(string: str) -> bool:
    """
    Check if the given string contains a Rubika link.

    :param string: Input string to check.
    :return: True if the string contains a Rubika link, False otherwise.
    """
    return bool(RUBIKA_LINK_PATTERN.search(string))

def is_group_link(string: str) -> bool:
    """
    Check if the given string contains a Rubika group link.

    :param string: Input string to check.
    :return: True if the string contains a Rubika group link, False otherwise.
    """
    return bool(GROUP_LINK_PATTERN.search(string))

def is_channel_link(string: str) -> bool:
    """
    Check if the given string contains a Rubika channel link.

    :param string: Input string to check.
    :return: True if the string contains a Rubika channel link, False otherwise.
    """
    return bool(CHANNEL_LINK_PATTERN.search(string))

def is_username(string: str) -> bool:
    """
    Check if the given string contains a Rubika username.

    :param string: Input string to check.
    :return: True if the string contains a Rubika username, False otherwise.
    """
    return bool(USERNAME_PATTERN.search(string))

# Functions to extract matches
def get_rubika_links(string: str) -> list:
    """
    Extract Rubika links from the given string.

    :param string: Input string to extract links from.
    :return: List of Rubika links found in the string.
    """
    return RUBIKA_LINK_PATTERN.findall(string)

def get_group_links(string: str) -> list:
    """
    Extract Rubika group links from the given string.

    :param string: Input string to extract group links from.
    :return: List of Rubika group links found in the string.
    """
    return GROUP_LINK_PATTERN.findall(string)

def get_channel_links(string: str) -> list:
    """
    Extract Rubika channel links from the given string.

    :param string: Input string to extract channel links from.
    :return: List of Rubika channel links found in the string.
    """
    return CHANNEL_LINK_PATTERN.findall(string)

def get_usernames(string: str) -> list:
    """
    Extract Rubika usernames from the given string.

    :param string: Input string to extract usernames from.
    :return: List of Rubika usernames found in the string.
    """
    return USERNAME_PATTERN.findall(string)
    

async def is_ad(text: str,mode: str = 'links') -> dict:
    if mode == 'links':
        if is_channel_link(text) or is_group_link(text):
            return {
            'is_link':True
            ,'channells':get_channel_links(text)
            ,'groups':get_group_links(text)
            }
        return {'is_link':False}
    elif mode == 'username':
        if is_username(text):
            return {
            'is_username':True
            ,'usernames':get_usernames(text)
            }
        return {'is_username':False}
            



