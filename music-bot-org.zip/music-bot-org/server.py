from fastapi import FastAPI, BackgroundTasks, HTTPException
import httpx
import aiofiles  # Asynchronous file handling
import os  # For path validation

app = FastAPI()

async def download_file(url: str, file_path: str):
    try:
        # Validate directory exists before downloading
        os.makedirs(os.path.dirname(file_path), exist_ok=True)

        async with httpx.AsyncClient() as client:
            response = await client.get(url)
            response.raise_for_status()  # Check response status
            async with aiofiles.open(file_path, 'wb') as f:
                async for chunk in response.aiter_bytes():
                    await f.write(chunk)  # Use await to handle async file write
    except Exception as e:
        print(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=f"Error downloading file: {e}")


@app.post("/download/")
async def download(url: str, file_path: str, background_tasks: BackgroundTasks):
    try:
        # Add background task for file download
        background_tasks.add_task(download_file, url, file_path)
        return {"message": "Download started", "file_path": file_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error starting download: {e}")
